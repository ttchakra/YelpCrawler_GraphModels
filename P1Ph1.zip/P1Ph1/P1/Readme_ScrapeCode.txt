--The code to scrape Yelp.com is in the 'Scrape_new.py' file. 

--You can run it simply by >>python Scrape_new.py OR open the file in a python editor (PyCharm) and run it on the console there.

--The visited nodes are appended to a file 'Output.txt' which will be created in the python directory

--This output file will contain the comma sepearted edge list unique userIDs given to each user within the URL of their homepage.

--A lot of information such as the entire URL etc of every url hit is printed on the console/terminal.

